package nodes;

/**
 * A general event
 * 
 * @author Afnarel
 */
public interface Event {
	
	public String getType();
	public int getStateID();
}
